package com.pm.Project_Management_Server.entity;


public enum ResourceLevel {
    JR,
    INTERMEDIATE,
    SR,
    ADVANCE,
    EXPERT
}

