package com.pm.Project_Management_Server.entity;

public enum UserType {
    ADMIN,
    USER
}
